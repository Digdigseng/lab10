<?php
namespace Src\Models;

use Src\Models\DatabaseConnection;

class User {
    private $db;

    public function __construct() {
        $this->db = DatabaseConnection::getInstance();
    }

    public function register($username, $email, $first_name, $last_name, $password) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $query = "INSERT INTO users (username, email, first_name, last_name, password) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([$username, $email, $first_name, $last_name, $hashed_password]);
    }

    public function login($username, $password) {
        $query = "SELECT * FROM users WHERE username = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        return $user && password_verify($password, $user['password']);
    }
}
