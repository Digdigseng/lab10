<?php
namespace Src\Controllers;

use Src\Models\User;

class LoginController extends BaseController {
    public function showForm() {
        $this->render('login-form');
    }

    public function login() {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        $user = new User();
        if ($user->login($username, $password)) {
            echo "Login successful! Welcome, $username.";
        } else {
            echo "Invalid username or password.";
        }
    }
}
