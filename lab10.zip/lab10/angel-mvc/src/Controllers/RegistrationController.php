<?php
namespace Src\Controllers;

use Src\Models\User;

class RegistrationController extends BaseController {
    public function showForm() {
        $this->render('registration-form');
    }

    public function register() {
        $errors = $this->validateRegistrationData($_POST);

        if (empty($errors)) {
            $user = new User();
            $user->register(
                $_POST['username'], 
                $_POST['email'], 
                $_POST['first_name'], 
                $_POST['last_name'], 
                $_POST['password']
            );
            echo "Successful Registration. <a href='/login-form'>Proceed to Login</a>";
        } else {
            foreach ($errors as $error) {
                echo "<p>$error</p>";
            }
        }
    }

    private function validateRegistrationData($data) {
        $errors = [];
        $required_fields = ['username', 'email', 'password', 'password_confirmation'];
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $errors[] = "$field is required.";
            }
        }

        $password = $data['password'];
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters.";
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one numeric character.";
        }
        if (!preg_match('/[A-Za-z]/', $password)) {
            $errors[] = "Password must contain at least one non-numeric character.";
        }
        if (!preg_match('/[!@#$%^&*-+]/', $password)) {
            $errors[] = "Password must contain at least one special character.";
        }

        if ($data['password'] !== $data['password_confirmation']) {
            $errors[] = "Password confirmation does not match.";
        }

        return $errors;
    }
}
