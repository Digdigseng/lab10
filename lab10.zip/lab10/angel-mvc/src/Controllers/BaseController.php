<?php
namespace Src\Controllers;

class BaseController {
    protected function render($viewName) {
        // Define the path to the views directory
        $viewPath = __DIR__ . "/../../views/$viewName.php";
        
        // Check if the view file exists
        if (file_exists($viewPath)) {
            include $viewPath;
        } else {
            echo "View $viewName not found.";
        }
    }
}
