<?php
require_once 'init.php';

use Src\Controllers\RegistrationController;
use Src\Controllers\LoginController;

$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

switch ($request_uri) {
    case '/index.php':
    case '/index.php/':
        // Display a creative, welcoming home page with styled links
        echo '<!DOCTYPE html>';
        echo '<html lang="en">';
        echo '<head>';
        echo '    <meta charset="UTF-8">';
        echo '    <title>Welcome</title>';
        echo '    <style>';
        echo '        body {';
        echo '            font-family: Arial, sans-serif;';
        echo '            background: linear-gradient(135deg, #ff9a9e, #fad0c4);';
        echo '            color: #333;';
        echo '            display: flex;';
        echo '            justify-content: center;';
        echo '            align-items: center;';
        echo '            height: 100vh;';
        echo '            margin: 0;';
        echo '            text-align: center;';
        echo '            animation: backgroundAnimation 6s infinite alternate;';
        echo '        }';
        echo '        @keyframes backgroundAnimation {';
        echo '            from { background: linear-gradient(135deg, #ff9a9e, #fad0c4); }';
        echo '            to { background: linear-gradient(135deg, #fad0c4, #ff9a9e); }';
        echo '        }';
        echo '        .content {';
        echo '            background: rgba(255, 255, 255, 0.8);';
        echo '            border-radius: 15px;';
        echo '            padding: 30px;';
        echo '            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);';
        echo '            max-width: 500px;';
        echo '            width: 90%;';
        echo '            animation: fadeIn 1.5s ease;';
        echo '        }';
        echo '        h1 {';
        echo '            font-size: 2.5em;';
        echo '            color: #333;';
        echo '            margin-bottom: 0.2em;';
        echo '        }';
        echo '        p {';
        echo '            font-size: 1.1em;';
        echo '            color: #555;';
        echo '            margin: 0.5em 0;';
        echo '        }';
        echo '        .menu {';
        echo '            margin-top: 20px;';
        echo '        }';
        echo '        .menu a {';
        echo '            display: inline-block;';
        echo '            margin: 10px 20px;';
        echo '            padding: 12px 20px;';
        echo '            color: #fff;';
        echo '            background-color: #ff6b6b;';
        echo '            border-radius: 50px;';
        echo '            text-decoration: none;';
        echo '            font-size: 1em;';
        echo '            transition: background-color 0.3s ease;';
        echo '        }';
        echo '        .menu a:hover {';
        echo '            background-color: #ee5253;';
        echo '        }';
        echo '        @keyframes fadeIn {';
        echo '            from { opacity: 0; transform: translateY(-20px); }';
        echo '            to { opacity: 1; transform: translateY(0); }';
        echo '        }';
        echo '    </style>';
        echo '</head>';
        echo '<body>';
        echo '    <div class="content">';
        echo '        <h1>Carlos Louis Elmido</h1>';
        echo '        <p>Your gateway to the best user experience!</p>';
        echo '        <p>Join us today to unlock all the features.</p>';
        echo '        <div class="menu">';
        echo '            <a href="/index.php/registration-form">Register</a>';
        echo '            <a href="/index.php/login-form">Login</a>';
        echo '        </div>';
        echo '    </div>';
        echo '</body>';
        echo '</html>';
        break;

    case '/index.php/registration-form':
        if ($method === 'GET') {
            (new RegistrationController())->showForm();
        }
        break;

    case '/index.php/register':
        if ($method === 'POST') {
            (new RegistrationController())->register();
        }
        break;

    case '/index.php/login-form':
        if ($method === 'GET') {
            (new LoginController())->showForm();
        }
        break;

    case '/index.php/login':
        if ($method === 'POST') {
            (new LoginController())->login();
        }
        break;

    default:
        echo "404 Not Found";
        break;
}
