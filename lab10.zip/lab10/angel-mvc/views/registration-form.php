<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #e09, #d0e);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            animation: gradientBackground 5s infinite alternate;
        }
        @keyframes gradientBackground {
            from { background: linear-gradient(135deg, #e09, #d0e); }
            to { background: linear-gradient(135deg, #d0e, #e09); }
        }
        .container {
            max-width: 320px;
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }
        .container:hover {
            transform: scale(1.03);
        }
        h2 {
            margin-bottom: 15px;
            font-size: 1.6em;
            color: #4a4e69;
        }
        label {
            display: block;
            margin-bottom: 4px;
            font-size: 0.85em;
            color: #4a4e69;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            font-size: 0.9em;
            text-align: center;
            transition: all 0.3s ease;
        }
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #a29bfe;
            box-shadow: 0 0 6px rgba(160, 150, 250, 0.5);
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #6c5ce7;
            color: #fff;
            border: none;
            border-radius: 20px;
            font-size: 0.9em;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #5a51d1;
        }
        .form-link {
            text-align: center;
            margin-top: 12px;
            font-size: 0.85em;
        }
        .form-link a {
            color: #6c5ce7;
            text-decoration: none;
            font-weight: bold;
        }
        .form-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Create Account</h2>
        <form action="/index.php/register" method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="first_name">First Name</label>
            <input type="text" id="first_name" name="first_name">

            <label for="last_name">Last Name</label>
            <input type="text" id="last_name" name="last_name">

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <label for="password_confirmation">Confirm Password</label>
            <input type="password" id="password_confirmation" name="password_confirmation" required>

            <button type="submit">Sign Up</button>
        </form>
        <div class="form-link">
            <p>Already a member? <a href="/index.php/login-form">Login</a></p>
        </div>
    </div>
</body>
</html>
