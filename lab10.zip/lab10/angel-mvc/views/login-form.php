<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f093fb, #f5576c);
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            animation: gradientBackground 5s infinite alternate;
        }
        @keyframes gradientBackground {
            from { background: linear-gradient(135deg, #f093fb, #f5576c); }
            to { background: linear-gradient(135deg, #f5576c, #f093fb); }
        }
        .container {
            max-width: 320px;
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease-in-out;
        }
        .container:hover {
            transform: scale(1.03);
        }
        h2 {
            margin-bottom: 15px;
            font-size: 1.6em;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 4px;
            font-size: 0.85em;
            color: #333;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            font-size: 0.9em;
            text-align: center;
            transition: all 0.3s ease;
        }
        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #ff6b6b;
            box-shadow: 0 0 6px rgba(255, 107, 107, 0.5);
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #ff6b6b;
            color: #fff;
            border: none;
            border-radius: 20px;
            font-size: 0.9em;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #ee5253;
        }
        .form-link {
            text-align: center;
            margin-top: 12px;
            font-size: 0.85em;
        }
        .form-link a {
            color: #ff6b6b;
            text-decoration: none;
            font-weight: bold;
        }
        .form-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Sign In</h2>
        <form action="/index.php/login" method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>
        <div class="form-link">
            <p>New here? <a href="/index.php/registration-form">Create an Account</a></p>
        </div>
    </div>
</body>
</html>
