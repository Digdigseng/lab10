<?php
// Autoload dependencies
require_once 'src/Models/DatabaseConnection.php';
require_once 'src/Models/User.php';
require_once 'src/Controllers/BaseController.php';
require_once 'src/Controllers/RegistrationController.php';
require_once 'src/Controllers/LoginController.php';

// Additional configuration can go here
